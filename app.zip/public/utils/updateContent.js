// Function to update the content area
export function updateContent(title, content) {
    contentArea.innerHTML = `<h2>${title}</h2><p>${content}</p>`;
};